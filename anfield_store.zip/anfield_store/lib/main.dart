import 'package:flutter/material.dart';
import 'package:carousel_pro/carousel_pro.dart';
import 'horizontal_listview.dart';
import 'products.dart';
import 'bottomnav.dart';

// import 'home.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: HomePage(),
  ));
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      appBar: new AppBar(
        backgroundColor: Colors.red,
        title: Text("Immortal Kop"),
        actions: <Widget>[
          new IconButton(
              icon: Icon(
                Icons.shopping_cart,
                color: Colors.white,
              ),
              onPressed: () {}),
          new IconButton(
              icon: Icon(
                Icons.search,
                color: Colors.white,
              ),
              onPressed: () {}),
        ],
      ),
      drawer: new Drawer(
        child: new ListView(children: <Widget>[
          DrawerHeader(
            child: Center(
              child: Text(
                'The Immortal Kopp',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white, fontSize: 25),
              ),
            ),
            decoration: BoxDecoration(
              color: Colors.red,
            ),
          ),
          InkWell(
              onTap: () {},
              child: ListTile(
                title: Text("Categories"),
                leading: Icon(Icons.dashboard, color: Colors.red),
              )),
          InkWell(
              onTap: () {},
              child: ListTile(
                title: Text("Cart"),
                leading: Icon(Icons.shopping_cart, color: Colors.red),
              )),
          InkWell(
              onTap: () {},
              child: ListTile(
                title: Text("Favourites"),
                leading: Icon(Icons.favorite, color: Colors.red),
              )),
          InkWell(
              onTap: () {},
              child: ListTile(
                title: Text("My Account"),
                leading: Icon(Icons.person, color: Colors.red),
              )),
          InkWell(
              onTap: () {},
              child: ListTile(
                title: Text("Settings"),
                leading: Icon(Icons.settings, color: Colors.red),
              )),
        ]),
      ),
      body: new ListView(
        children: <Widget>[
          new Padding(
            //Padding my widget and adding my horizontal view
            padding: const EdgeInsets.all(9.0),
            child: new Text('Categories'),
          ),
          //Importing horizontal list view
          HorizontalList(),
          new Padding(
            //Padding my widget and adding my horizontal view
            padding: const EdgeInsets.all(14.0),
            child: new Text('Latest Release'),
          ),
          //Grid View
          Container(
            height: 600.0,
            child: Products(),
          ),
        ],
      ),
      bottomNavigationBar: MyBottomNavBar(),
    );
  }
}
