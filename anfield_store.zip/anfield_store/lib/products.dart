import 'package:flutter/material.dart';

class Products extends StatefulWidget {
  @override
  _ProductsState createState() => _ProductsState();
}

class _ProductsState extends State<Products> {
  var product_list = [
    {
      "name": "LFC Mens Shirt",
      "picture": "images/image7.jpg",
      "old_price": 60,
      "price": 49,
    },
    {
      "name": "LFC Kids Hoodie",
      "picture": "images/image8.jpg",
      "old_price": 87,
      "price": 63,
    },
    {
      "name": "LFC Weekend Fit",
      "picture": "images/image9.jpg",
      "old_price": 120,
      "price": 83,
    },
    {
      "name": "Grey Sweat Shirt",
      "picture": "images/image10.jpg",
      "old_price": 120,
      "price": 89,
    },
    {
      "name": "LFC Sweat Shirt",
      "picture": "images/image11.jpg",
      "old_price": 84,
      "price": 74,
    },
    {
      "name": "LFC Black Kit",
      "picture": "images/image12.jpg",
      "old_price": 94,
      "price": 80,
    },
  ];
  @override
  Widget build(BuildContext context) {
    return GridView.builder(
        itemCount: product_list.length,
        gridDelegate:
            new SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
        itemBuilder: (BuildContext context, int index) {
          return Single_Product(
            product_name: product_list[index]['name'],
            product_image: product_list[index]['picture'],
            product_oldprice: product_list[index]['old_price'],
            product_price: product_list[index]['price'],
          );
        });
  }
}

class Single_Product extends StatelessWidget {
  final product_name;
  final product_image;
  final product_oldprice;
  final product_price;

  Single_Product({
    this.product_name,
    this.product_image,
    this.product_oldprice,
    this.product_price,
  });
  @override
  Widget build(BuildContext context) {
    return Card(
      child: Hero(
        tag: product_name,
        child: Material(
          child: InkWell(
            onTap: () {},
            child: GridTile(
              footer: Container(
                color: Colors.white60,
                child: ListTile(
                  leading: Text(
                    product_name,
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  title: Text(
                    "\$$product_price",
                    style: TextStyle(
                        color: Colors.red, fontWeight: FontWeight.w800),
                  ),
                  subtitle: Text(
                    "\$$product_oldprice",
                    style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.w800,
                        decoration: TextDecoration.lineThrough),
                  ),
                ),
              ),
              child: Image.asset(
                product_image,
                fit: BoxFit.cover,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
