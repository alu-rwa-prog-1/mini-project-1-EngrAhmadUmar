import 'package:flutter/material.dart';

class MyBottomNavBar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 50,
      padding: EdgeInsets.only(top: 0, bottom: 10),
      // color: Color.fromARGB(70, 70, 0, 0),
      color: Colors.white30,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: <Widget>[
          IconButton(
            icon: Icon(
              Icons.home,
              size: 35.0,
              color: Colors.red,
            ),
            onPressed: () {
              // print('Home');
            },
          ),
          IconButton(
            icon: Icon(
              Icons.shopping_cart,
              size: 35.0,
              color: Colors.red,
            ),
            onPressed: () {
              // print('Camera');
            },
          ),
          IconButton(
            icon: Icon(
              Icons.favorite,
              size: 35.0,
              color: Colors.red,
            ),
            onPressed: () {
              // print('Camera');
            },
          ),
          IconButton(
            icon: Icon(
              Icons.settings,
              size: 35.0,
              color: Colors.red,
            ),
            onPressed: () {
              // print('Camera');
            },
          )
        ],
      ),
    );
  }
}
